jQuery('#email-form').validate({

    rules:{
        name:"required",
    },
    messages:{
        name:"Please Enter Your name"
    }

});
